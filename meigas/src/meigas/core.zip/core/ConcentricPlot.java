package es.unex.meigas.core;

import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class ConcentricPlot
         extends
            Plot {

   private static final int PLOTS_COUNT = 5;
   private final Double[]   m_dRadius;
   private final Double[]   m_dMinDiameter;


   public ConcentricPlot() {

      super();

      int i;

      m_dRadius = new Double[PLOTS_COUNT];
      m_dMinDiameter = new Double[PLOTS_COUNT];

      for (i = 0; i < PLOTS_COUNT; i++) {
         m_dRadius[i] = new Double(NO_DATA);
         m_dMinDiameter[i] = new Double(NO_DATA);
      }

   }


   public Double[] getRadius() {

      return m_dRadius;

   }


   public void setRadius(final Double[] dRadius) {

      int i;

      for (i = 0; i < dRadius.length; i++) {
         if (!dRadius[i].equals(m_dRadius[i])) {
            m_dRadius[i] = dRadius[i];
            setHasChanged(true);
         }
      }

   }


   public Double[] getMinAcceptableDiameters() {

      return m_dMinDiameter;

   }


   public void setMinAcceptableDiameters(final Double[] dDiameter) {

      int i;

      for (i = 0; i < dDiameter.length; i++) {
         if (!dDiameter[i].equals(m_dMinDiameter[i])) {
            m_dMinDiameter[i] = dDiameter[i];
            setHasChanged(true);
         }
      }

   }


   @Override
   public double getArea() {

      final double dRadius = getMaxRadius();

      if (dRadius != NO_DATA) {
         return (Math.PI * Math.pow(dRadius, 2.) / 10000.);
      }
      else {
         return NO_DATA;
      }

   }


   public double getMaxRadius() {

      int i;
      int iIndex = -1;

      for (i = 0; i < PLOTS_COUNT; i++) {
         if (m_dRadius[i].doubleValue() == NO_DATA) {
            iIndex = i - 1;
            break;
         }
      }

      if (iIndex >= 0) {
         return m_dRadius[iIndex].doubleValue();
      }
      else {
         return NO_DATA;
      }

   }


   @Override
   public Rectangle2D getBoundingBox() {

      final double dRadius = getMaxRadius();

      if (dRadius != NO_DATA) {
         return new Rectangle2D.Double(m_CoordX - dRadius, m_CoordY - dRadius, dRadius * 2, dRadius * 2);
      }
      else {
         return null;
      }

   }


   public double[] getDistribution(final String sSpecie,
                                   final int iInterval,
                                   final int iParameter) {

      int i, j;
      int iCount;
      int iClass, iClass2;
      int iClasses;
      int iMaxDiameter;
      int iTreesCount = 0;
      double dDiameter;
      double dValue;
      double area[];
      String s;
      final ArrayList trees = getTrees(getFilters());
      Tree tree;

      iMaxDiameter = (int) Math.ceil(getMaximumDiameter(trees));
      iClasses = iMaxDiameter;

      if (iClasses == 0) {
         return null;
      }

      area = new double[iClasses];

      iCount = getConcentricPlotsCount();
      if (iCount == 0) {
         return null;
      }

      for (i = 0; i < iClasses; i++) {
         for (j = 0; j < iCount; j++) {
            if (i < m_dMinDiameter[j].doubleValue()) {
               break;
            }
         }
         if (j == 0) {
            area[i] = (Math.PI * Math.pow(m_dRadius[0].doubleValue(), 2.) / 10000.);
         }
         else {
            area[i] = (Math.PI * Math.pow(m_dRadius[j - 1].doubleValue(), 2.) / 10000.);
         }
      }

      final double distribution[] = new double[iClasses];
      final int treesCount[] = new int[iClasses];

      for (i = 0; i < iClasses; i++) {
         distribution[i] = 0;
         treesCount[i] = 0;
      }

      for (i = 0; i < trees.size(); i++) {
         tree = (Tree) trees.get(i);
         s = tree.getSpecie();
         if (s.equals(sSpecie) || sSpecie.equals("Todas")) {
            dDiameter = tree.getDBH().getValue();
            if (dDiameter != NO_DATA) {
               switch (iParameter) {
                  case FREQUENCY:
                     dValue = 1;
                     break;
                  case HEIGHT:
                     dValue = tree.getHeight().getValue();
                     break;
                  case LOG_HEIGHT:
                     dValue = tree.getLogHeight().getValue();
                     break;
                  case VOLUME:
                     dValue = tree.getVolumeWithBark().getValue();
                     break;
                  case VOLUME_WITHOUT_BARK:
                     dValue = tree.getVolumeWithoutBark().getValue();
                     break;
                  case AGE:
                     dValue = tree.getAge().getValue();
                     break;
                  case BASIMETRIC_AREA:
                     dValue = tree.getBasimetricArea();
                     break;
                  default:
                     return null;
               }
               if (dValue != NO_DATA) {
                  iClass = (int) Math.floor(dDiameter);
                  iClass = Math.min(iClass, iClasses - 1);
                  distribution[iClass] += dValue;
                  treesCount[iClass]++;
               }
            }
         }
      }

      if (iParameter == FREQUENCY) {
         for (i = 0; i < iClasses; i++) {
            distribution[i] /= area[i];
         }
      }

      iClasses = (int) Math.ceil((double) iMaxDiameter / (double) iInterval);
      final double ret[] = new double[iClasses];

      for (i = 0; i < iClasses; i++) {
         ret[i] = 0;
      }

      for (iClass = 0, iClass2 = 0; iClass < iClasses; iClass++, iClass2 += iInterval) {
         iTreesCount = 0;
         for (i = 0; i < iInterval; i++) {
            if (iClass2 + i < iMaxDiameter) {
               ret[iClass] += distribution[iClass2 + i];
               iTreesCount += treesCount[iClass2 + i];
            }
         }
         if (iParameter != FREQUENCY) {
            if (iTreesCount != 0) {
               ret[iClass] /= (iTreesCount);
            }
         }
      }

      return ret;

   }


   private int getConcentricPlotsCount() {

      int i;

      for (i = 0; i < PLOTS_COUNT; i++) {
         if ((m_dRadius[i].doubleValue() == NO_DATA) && (m_dMinDiameter[i].doubleValue() == NO_DATA)) {
            break;
         }
      }

      return i;
   }


   @Override
   public String[] getReport() {
      // TODO Auto-generated method stub
      return null;
   }

}
