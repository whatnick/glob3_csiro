package es.unex.meigas.core;

public class Specie {

   public Specie(final String sName) {

      name = sName;

   }


   @Override
   public String toString() {

      return name;

   }

   public String name;

}
