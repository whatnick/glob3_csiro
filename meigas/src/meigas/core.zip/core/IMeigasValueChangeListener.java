package es.unex.meigas.core;

public interface IMeigasValueChangeListener {
	
	public void valueHasChanged();

}
