package es.unex.meigas.core.gis;

import es.unex.meigas.dataObjects.IVectorLayer;

public class GISConnection {

   public IVectorLayer[] getVectorLayers(final int shapeType) {
      // TODO Auto-generated method stub
      return null;
   }

}
